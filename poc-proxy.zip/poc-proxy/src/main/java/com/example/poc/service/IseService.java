package com.example.poc.service;

import com.example.poc.model.IseType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
public class IseService {

    private final WebClient iseWebClient;
    private final WebClient iseWebClientWithProxy;

    public IseService(@Qualifier("iseWebClient") WebClient iseWebClient,
                      @Qualifier("iseWebClientWithProxy") WebClient iseWebClientWithProxy) {
        this.iseWebClient = iseWebClient;
        this.iseWebClientWithProxy = iseWebClientWithProxy;
    }

    public Mono<String> getTacacsCommandsDirect(IseType ise) {
        String url = String.format("http://%s:8080/tacacs-commands", ise.toHost());
        return iseWebClient
                .get()
                .uri(url)
                .retrieve()
                .bodyToMono(String.class);
    }

    public Mono<String> getTacacsCommandsProxy(IseType ise) {
        String url = String.format("http://%s:8080/tacacs-commands", ise.toHost());
        return iseWebClientWithProxy
                .get()
                .uri(url)
                .retrieve()
                .bodyToMono(String.class);
    }
}


