package com.example.poc.controller;

import com.example.poc.model.IseType;
import com.example.poc.service.IseService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")
public class IseController {

    private final IseService iseService;

    public IseController(IseService iseService) {
        this.iseService = iseService;
    }

    @GetMapping(value = "/{ise}/tacacs-commands/direct", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<String> getTacacsDirect(@PathVariable("ise") IseType ise) {
        return iseService.getTacacsCommandsDirect(ise);
    }

    @GetMapping(value = "/{ise}/tacacs-commands/proxy", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<String> getTacacsProxy(@PathVariable("ise") IseType ise) {
        return iseService.getTacacsCommandsProxy(ise);
    }
}
