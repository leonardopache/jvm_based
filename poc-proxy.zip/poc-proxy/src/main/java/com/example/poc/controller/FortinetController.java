package com.example.poc.controller;

import com.example.poc.service.FortinetService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/fortinet")
public class FortinetController {

    private final FortinetService fortinetService;

    public FortinetController(FortinetService fortinetService) {
        this.fortinetService = fortinetService;
    }

    @GetMapping(value = "/{hostName}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<String> callFortinet(@PathVariable("hostName") String hostName) {
        return fortinetService.callFortinet(hostName);
    }
}
