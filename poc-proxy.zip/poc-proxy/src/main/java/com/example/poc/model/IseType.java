package com.example.poc.model;

public enum IseType {
    TEST,
    DMZ;

    public String toHost() {
        return name();
    }
}


