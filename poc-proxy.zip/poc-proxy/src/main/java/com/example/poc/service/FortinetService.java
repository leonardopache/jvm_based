package com.example.poc.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
public class FortinetService {

    private final WebClient fortinetWebClientWithProxy;

    public FortinetService(@Qualifier("fortinetWebClientWithProxy") WebClient fortinetWebClientWithProxy) {
        this.fortinetWebClientWithProxy = fortinetWebClientWithProxy;
    }

    public Mono<String> callFortinet(String hostName) {
        String url = String.format("https://%s:443/jsonrpc", hostName);
        return fortinetWebClientWithProxy
                .post()
                .uri(url)
                .body(Mono.empty(), Void.class)
                .retrieve()
                .bodyToMono(String.class);
    }
}
