package com.example.poc.config;

import io.netty.handler.proxy.ProxyHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;

@Configuration
public class WebClientConfig {

    @Value("${proxies.ise-proxy.host}")
    private String iseProxyHost;

    @Value("${proxies.ise-proxy.port}")
    private int iseProxyPort;

    @Value("${proxies.snap-proxy.host}")
    private String snapProxyHost;

    @Value("${proxies.snap-proxy.port}")
    private int snapProxyPort;

    @Bean
    public WebClient fortinetWebClientWithProxy() {
        HttpClient httpClient = HttpClient.create()
                .proxy(proxy -> proxy.type(ProxyProvider.Proxy.HTTP)
                        .host(iseProxyHost)
                        .port(iseProxyPort));

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    @Bean
    public WebClient iseWebClientWithProxy() {
        HttpClient httpClient = HttpClient.create()
                .proxy(proxy -> proxy.type(ProxyProvider.Proxy.HTTP)
                        .host(snapProxyHost)
                        .port(snapProxyPort));

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    @Bean
    public WebClient iseWebClient() {
        return WebClient.builder().build();
    }
}
